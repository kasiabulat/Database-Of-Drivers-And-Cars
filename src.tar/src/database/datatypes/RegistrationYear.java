package database.datatypes;

/**
 Created by Kamil Rajtar on 15.06.16. */
public class RegistrationYear
{
	public final Integer year;
	public final Integer count;

	public RegistrationYear(final Integer year,final Integer count)
	{
		this.year=year;
		this.count=count;
	}
}
